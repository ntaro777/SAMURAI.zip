const stripe = Stripe('pk_test_51QkMgRALb4eLQ2oWQIjPVnDKdAiC2wlBdYFCr3xwCHtu0S5hPnyPHpMCNc8raU2cTa05I7OaoNToMWpFM9HOzvCt00OSajSxGi');
const paymentButton = document.querySelector('#paymentButton');

paymentButton.addEventListener('click', () => {
 stripe.redirectToCheckout({
   sessionId: sessionId
 })
});